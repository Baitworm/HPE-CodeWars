import java.io.*;
import java.util.Scanner;

public class prob01{
    
    public static void main(String[] args) throws FileNotFoundException{
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        String name = chop.nextLine();
        chop.close();
        System.out.println(name + ", " + "the needs of the many outweigh the needs of the few, or the one; live long and prosper.");
    }

    
    
}