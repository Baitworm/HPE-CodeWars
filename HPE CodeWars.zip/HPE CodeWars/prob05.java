import java.io.*;
import java.util.Scanner;
import java.util.Map;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
public class prob05{
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        int n = chop.nextInt();
        chop.nextLine();
        Map<String,Integer> map = new HashMap<>();

        while (n > 0){
            String date = chop.nextLine();
            String birthday = date.split("/")[0] + "/" + date.split("/")[1];
            if(!map.containsKey(birthday))
                map.put(birthday,0);
            else{
                map.replace(birthday, map.get(birthday) + 1);
            }
            n -= 1;
        }
        chop.close();

        int amt_dupes = 0;
        String output = "duplicates: ";
        String[] keyList = map.keySet().toArray(new String[0]);
        Arrays.sort(keyList,Collections.reverseOrder());
        
        for (int i = keyList.length - 1; i >= 0 ; i --){
            String key = keyList[i];
            if (map.get(key) > 0){
                amt_dupes += 1;
                if (!output.contains(key))
                    output = output + key + " ";
            }
        }

        if (output.equals("duplicates: "))
            output = output + "None";
        
        System.out.println(amt_dupes);
        System.out.println(output);
    }
}