import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map.Entry;

public class prob20 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        Map<String,Integer> map = new TreeMap<>();
        int n = chop.nextInt();
        chop.nextLine();
        for (int i = 0; i < n; i++){
            String height_and_address = chop.nextLine();
            Integer height = Integer.parseInt(height_and_address.split(" ")[0]);
            String address = height_and_address.split(" ")[1];
            map.put(address, height);
        }
        chop.close();
        List<Entry<String,Integer>> list = new ArrayList<>();
        list.addAll(map.entrySet());
        Collections.sort(list,Entry.comparingByValue());
        Integer cur_height = list.get(list.size()-1).getValue();
        boolean[] touched = new boolean[list.size()];
        while (cur_height >= 0){
            for (int i = 0; i < list.size(); i++){
                Entry<String,Integer> entry = list.get(i);
                if (entry.getValue() == cur_height){
                    list.get(i).setValue(list.get(i).getValue() - 1);
                    if(touched[i] == true){
                        System.out.print("*");
                    }
                    else{
                        System.out.print("~");
                        touched[i] = true;
                    }
                }
                else
                    System.out.print(" ");
            }
            cur_height--;
            System.out.println();
        }
        for (int i = 0; i < list.size(); i++){
            System.out.print(list.get(i).getKey());
        }
    }
}
