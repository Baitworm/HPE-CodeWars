import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.awt.Point;

public class prob26 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        int width = chop.nextInt();
        int height = chop.nextInt();
        int num_doors = chop.nextInt();
        chop.nextLine();
        String[][] mat = new String[height][width];
        int row = 0;
        Map<String, Integer[]> map = new HashMap<>();
        Point begPoint = new Point();
        Point endPoint = new Point();
        while (chop.hasNextLine()) {
            String cur_line = chop.nextLine();
            if (cur_line.matches(".*\\d.*")){
                Integer[] attribtues = new Integer[3];
                String[] things = cur_line.split(" ");
                for (int i = 1; i < things.length; i++)
                    attribtues[i-1] = Integer.parseInt(things[i]);
                map.put(things[0], attribtues);
            }
            else{
                for (int i = 0; i < cur_line.length(); i++){
                    String character = cur_line.charAt(i) + "";    
                    if (character.equals("B"))
                        begPoint.setLocation(new Point(i, row));
                    if (character.equals("F"))
                        endPoint.setLocation(new Point(i, row));
                    mat[row][i] = character;
                }
            }                    
            row++;
        }
        chop.close();
        
        
    }
    public static String findPath(String[][] mat, Map<String,Integer> map, int time_taken, Point cur_point, String path_taken){
        if (mat[(int)cur_point.getX()][(int)cur_point.getY()].equals("F"))
            return path_taken;
        
        // check bounds
        //check doors
        // brute force
    }
}
