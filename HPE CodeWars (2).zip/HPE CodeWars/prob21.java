import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class prob21 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        List<String[]> search = new ArrayList<>();
        List<Integer[]> location_of_m = new ArrayList<>();
        while (chop.hasNextLine()){
            String line = chop.nextLine();
            String[] to_add = new String[line.length()];
            char[] char_array = line.toCharArray();
            for (int i = 0; i < char_array.length; i++){
                to_add[i] = char_array[i] + "";
                if (to_add[i].equals("M"))
                    location_of_m.add(new Integer[]{search.size(),i});
            }            
            search.add(to_add);
        }

        chop.close();
        
        for(int i = 0; i < location_of_m.size(); i++){
            Integer[] coords = location_of_m.get(i); 
            if (coords[0] - 1 > 0 && search.get(coords[0]-1)[coords[1]].equals("O")){
                if (check_vertical(search, false, coords)){
                    for (int j = 0; j < 4; j++){
                        int current_x = coords[0] - j;
                        int current_y = coords[1];
                        System.out.println(search.get(current_x)[current_y] + ": " + current_x +"," + current_y);
                    }
                }
            }
            if (coords[0] + 1 < search.size() && search.get(coords[0] + 1)[coords[1]].equals("O")){
                if (check_vertical(search, true, coords)){
                    for (int j = 0; j < 4; j++){
                        int current_x = coords[0] + j;
                        int current_y = coords[1];
                        System.out.println(search.get(current_x)[current_y] + ": " + current_x +"," + current_y);
                    }
                }
            }
            if(coords[1] + 1 < search.get(coords[0]).length && search.get(coords[0])[coords[1] + 1].equals("O")){
                if (check_horizontal(search, true, coords)){
                    for (int j = 0; j < 4; j++){
                        int current_x = coords[0] ;
                        int current_y = coords[1] + j;
                        System.out.println(search.get(current_x)[current_y] + ": " + current_x +"," + current_y);
                    }
                }
            }
            if(coords[1] - 1 < 0 && search.get(coords[0])[coords[1] - 1].equals("O")){
                if (check_horizontal(search, false, coords)){
                    for (int j = 0; j < 4; j++){
                        int current_x = coords[0] ;
                        int current_y = coords[1] - j;
                        System.out.println(search.get(current_x)[current_y] + ": " + current_x +"," + current_y);
                    }
                }
                if (check_square(search, coords)){
                    // print square
                }
            }
        }
        
    }
    public static boolean check_vertical(List<String[]> search, boolean dir, Integer[] coords){
        if (!dir && coords[0]-3 > 0){
            return search.get(coords[0]-2)[coords[1]].equals("J") && search.get(coords[0]-3)[coords[1]].equals("O");
        }
        if (coords[0] + 3 < search.size()){
            return search.get(coords[0]+2)[coords[1]].equals("J") && search.get(coords[0]+3)[coords[1]].equals("O");
        }
        return false;
    }

    public static boolean check_horizontal(List<String[]> search, boolean dir, Integer[] coords){
        if (!dir && coords[1]-3 > 0){
            return search.get(coords[0])[coords[1] - 2].equals("O") && search.get(coords[0])[coords[1] - 3].equals("O");
        }
        if (coords[1] + 3 < search.get(coords[0]).length){
            return search.get(coords[0])[coords[1] + 2].equals("O") && search.get(coords[0])[coords[1] + 3].equals("O");
        }
        return false;
    }

    public static boolean check_square(List<String[]> search, Integer[] coords){
        if (coords[0] + 1 < search.size() && coords[1] + 1 < search.get(coords[0]).length)
            return search.get(coords[0])[coords[1] + 1].equals("O") && search.get(coords[0]+ 1)[coords[1] + 1].equals("O") && search.get(coords[0] + 1)[coords[1] ].equals("J");
        return false;
    }
}
