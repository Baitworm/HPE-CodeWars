import java.io.*;
import java.util.Scanner;

public class prob11 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        String[] variables = new String[3];
        int index = 0;
        for (int i = 0 ; i < variables.length; i++){
            variables[i] = chop.nextLine();
            
            if (variables[i].split(" ")[1].equals("?"))
                index = i;
        }
        chop.close();
        
        String output = "";

        if (index == 0)
            output += "F " + String.format("%.2f",(-Double.parseDouble(variables[1].split(" ")[1]) * Double.parseDouble(variables[2].split(" ")[1])));
        else{
            if (index == 1){
                output += "K " + String.format("%.2f",(Double.parseDouble(variables[0].split(" ")[1]) / -Double.parseDouble(variables[2].split(" ")[1])));
            }
            else
                output += "X " + String.format("%.2f",(Double.parseDouble(variables[0].split(" ")[1]) / -Double.parseDouble(variables[1].split(" ")[1])));
        }
        System.out.println(output);

    }
}
