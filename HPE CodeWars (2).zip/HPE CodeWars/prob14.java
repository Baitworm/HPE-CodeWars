import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class prob14 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        int num_sticks = chop.nextInt();
        String size = chop.next();
        Double size_stick = size.contains("/")? Double.parseDouble(size.split("/")[0]) / Double.parseDouble(size.split("/")[1]): Double.parseDouble(size); 
        Double tensile_limit = chop.nextDouble();
        Double energy_output = num_sticks * size_stick * .45 * 7.5;
        chop.close();
        System.out.println(String.format("%.2f",energy_output) + " " + (energy_output <= tensile_limit? "the Mask can eat it!": "the Mask should not eat it!"));
    }
}
