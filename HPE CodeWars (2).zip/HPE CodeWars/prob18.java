import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class prob18 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        
        String method = chop.nextLine();
        int num_people_required = chop.nextInt();
        double amt_time_ran = chop.nextDouble() * 60; // multipy by 60 to convert to seconds
        double startup_time = chop.nextDouble();
        double watts = chop.nextDouble() / 360; // divide 360 to convert to seconds
        int num_people_available = chop.nextInt();
        chop.close()
        String watts_per_second = String.format("%.2f", watts);
        String gigawatts_per_second = String.format("%.2f", watts/100);
        if(num_people_available < num_people_required || amt_time_ran < startup_time)
            gigawatts_per_second = "0.00";
            watts_per_second = "0.00";
        System.out.println(method + " " + "can generate " + watts_per_second + " watts/second");
        System.out.println(Double.parseDouble(gigawatts_per_second)> 1.21 ? "MARTY CAN MAKE IT!" : "WHOA HEAVY!");
    }
}
