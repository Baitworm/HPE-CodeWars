import java.io.*;
import java.util.Scanner;
public class prob02 {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("input.txt");
        Scanner chop = new Scanner(file);
        double height = chop.nextDouble();
        double radius = chop.nextDouble();
        chop.close();
        double volume = Math.PI * radius * radius * height;
        System.out.println(String.format("%.2f", volume) + " " + "cubic inches"); 
    }
}
